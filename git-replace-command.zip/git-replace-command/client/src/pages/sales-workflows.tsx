import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { FileText, Copy, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SalesWorkflows() {
  const [step1, setStep1] = useState("");
  const [step2, setStep2] = useState("");
  const [step3, setStep3] = useState("");
  const [step4, setStep4] = useState("");
  const [step5, setStep5] = useState("");
  const [step6, setStep6] = useState("");
  const [step7, setStep7] = useState("");
  const [step8, setStep8] = useState("");
  const [step9, setStep9] = useState("");
  const [step10, setStep10] = useState("");
  const [step11, setStep11] = useState("");
  const [step12, setStep12] = useState("");
  const [error, setError] = useState("");
  const [step1Copied, setStep1Copied] = useState(false);
  const [step2Copied, setStep2Copied] = useState(false);
  const [step3Copied, setStep3Copied] = useState(false);
  const [step4Copied, setStep4Copied] = useState(false);
  const [step5Copied, setStep5Copied] = useState(false);
  const [step6Copied, setStep6Copied] = useState(false);
  const [step7Copied, setStep7Copied] = useState(false);
  const [step8Copied, setStep8Copied] = useState(false);
  const [step9Copied, setStep9Copied] = useState(false);
  const [step10Copied, setStep10Copied] = useState(false);
  const [step11Copied, setStep11Copied] = useState(false);
  const [step12Copied, setStep12Copied] = useState(false);

  const handleInputChange = () => {
    setError("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Input Form */}
        <Card className="mb-6 shadow-lg border-0 bg-white/90 backdrop-blur-sm" data-testid="card-input-form">
          <CardHeader className="pb-4">
            <div className="flex items-center space-x-2">
              <FileText className="h-6 w-6 text-blue-500" />
              <CardTitle className="text-xl font-semibold text-gray-800">
                Sales Workflows Configuration
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Subject */}
            <div>
              <Label htmlFor="subject" className="text-sm font-medium text-gray-700">
                Subject
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="subject"
                  type="text"
                  placeholder="Asking Permission About Your Business [shop_name] to be listed on www.testplaceholder.comm"
                  value={step1}
                  onChange={(e) => {
                    setStep1(e.target.value);
                    handleInputChange();
                  }}
                  onFocus={(e) => {
                    if (!step1) {
                      setStep1("Asking Permission About Your Business [shop_name] to be listed on www.testplaceholder.comm");
                    }
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400 h-12 text-sm"
                  data-testid="input-subject"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step1);
                    setStep1Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-1"
                >
                  {step1Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 2 */}
            <div>
              <Label htmlFor="step-2" className="text-sm font-medium text-gray-700">
                Step 2
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-2"
                  type="text"
                  placeholder="Enter step 2"
                  value={step2}
                  onChange={(e) => {
                    setStep2(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-2"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step2);
                    setStep2Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-2"
                >
                  {step2Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 3 */}
            <div>
              <Label htmlFor="step-3" className="text-sm font-medium text-gray-700">
                Step 3
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-3"
                  type="text"
                  placeholder="Enter step 3"
                  value={step3}
                  onChange={(e) => {
                    setStep3(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-3"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step3);
                    setStep3Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-3"
                >
                  {step3Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 4 */}
            <div>
              <Label htmlFor="step-4" className="text-sm font-medium text-gray-700">
                Step 4
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-4"
                  type="text"
                  placeholder="Enter step 4"
                  value={step4}
                  onChange={(e) => {
                    setStep4(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-4"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step4);
                    setStep4Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-4"
                >
                  {step4Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 5 */}
            <div>
              <Label htmlFor="step-5" className="text-sm font-medium text-gray-700">
                Step 5
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-5"
                  type="text"
                  placeholder="Enter step 5"
                  value={step5}
                  onChange={(e) => {
                    setStep5(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-5"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step5);
                    setStep5Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-5"
                >
                  {step5Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 6 */}
            <div>
              <Label htmlFor="step-6" className="text-sm font-medium text-gray-700">
                Step 6
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-6"
                  type="text"
                  placeholder="Enter step 6"
                  value={step6}
                  onChange={(e) => {
                    setStep6(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-6"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step6);
                    setStep6Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-6"
                >
                  {step6Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 7 */}
            <div>
              <Label htmlFor="step-7" className="text-sm font-medium text-gray-700">
                Step 7
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-7"
                  type="text"
                  placeholder="Enter step 7"
                  value={step7}
                  onChange={(e) => {
                    setStep7(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-7"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step7);
                    setStep7Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-7"
                >
                  {step7Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 8 */}
            <div>
              <Label htmlFor="step-8" className="text-sm font-medium text-gray-700">
                Step 8
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-8"
                  type="text"
                  placeholder="Enter step 8"
                  value={step8}
                  onChange={(e) => {
                    setStep8(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-8"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step8);
                    setStep8Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-8"
                >
                  {step8Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 9 */}
            <div>
              <Label htmlFor="step-9" className="text-sm font-medium text-gray-700">
                Step 9
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-9"
                  type="text"
                  placeholder="Enter step 9"
                  value={step9}
                  onChange={(e) => {
                    setStep9(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-9"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step9);
                    setStep9Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-9"
                >
                  {step9Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 10 */}
            <div>
              <Label htmlFor="step-10" className="text-sm font-medium text-gray-700">
                Step 10
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-10"
                  type="text"
                  placeholder="Enter step 10"
                  value={step10}
                  onChange={(e) => {
                    setStep10(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-10"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step10);
                    setStep10Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-10"
                >
                  {step10Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 11 */}
            <div>
              <Label htmlFor="step-11" className="text-sm font-medium text-gray-700">
                Step 11
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-11"
                  type="text"
                  placeholder="Enter step 11"
                  value={step11}
                  onChange={(e) => {
                    setStep11(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-11"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step11);
                    setStep11Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-11"
                >
                  {step11Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Step 12 */}
            <div>
              <Label htmlFor="step-12" className="text-sm font-medium text-gray-700">
                Step 12
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="step-12"
                  type="text"
                  placeholder="Enter step 12"
                  value={step12}
                  onChange={(e) => {
                    setStep12(e.target.value);
                    handleInputChange();
                  }}
                  className="pr-20 border-gray-200 focus:border-blue-400 focus:ring-blue-400"
                  data-testid="input-step-12"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(step12);
                    setStep12Copied(true);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 border-gray-300 hover:bg-gray-50"
                  data-testid="button-copy-step-12"
                >
                  {step12Copied ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1 text-green-600" />
                      Done
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {error && (
              <Alert className="border-red-200 bg-red-50/50" data-testid="alert-error">
                <AlertDescription className="text-red-700">{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}